public class Milk extends Product{
    private double amountM;

    public Milk(int id, String name, double price, double amountM){
        super(id, name, price);
        this.amountM = amountM;
    }
    public Milk(){

    }

    public double getAmountM() {
        return amountM;
    }
    public void setAmountM(double amountM) {
        this.amountM = amountM;
    }

    @Override
    public void count(){
        System.out.println("The price is " + getPrice()*getAmountM());
    }
}
