public class Bakery extends Product{
    private double amountB;

    public Bakery(int id, String name, double price, double amountB){
        super(id, name, price);
        this.amountB = amountB;
    }
    public Bakery(){

    }

    public double getAmountB() {
        return amountB;
    }
    public void setAmountB(double amountB) {
        this.amountB = amountB;
    }

    @Override
    public void count(){
        System.out.println("The price is " + getPrice()*getAmountB());
    }
}
