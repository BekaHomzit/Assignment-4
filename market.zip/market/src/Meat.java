public class Meat extends Product{
    private double weightM;

    public Meat(int id, String name, double price, double weightM){
        super(id, name, price);
        this.weightM = weightM;
    }
    public Meat(){

    }

    public double getWeightM() {
        return weightM;
    }
    public void setWeightM(double weightM) {
        this.weightM = weightM;
    }

    @Override
    public void count(){
        System.out.println("The price is " + getPrice()*getWeightM());
    }
}
