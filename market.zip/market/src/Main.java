public class Main {
    public static void main(String[] args) {
        Sweets snickers = new Sweets(101, "Snickers", 4500, 0.5);
        Meat beef = new Meat(201, "Beef", 5000, 1.5);
        Fruit apple = new Fruit(301, "Apple", 500, 2);
        Bakery bread = new Bakery(401, "Bread", 150, 3);
        Milk milk = new Milk(501, "Milk", 450, 1);

    }
}